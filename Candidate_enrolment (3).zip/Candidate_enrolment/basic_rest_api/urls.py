from django.contrib import admin
from django.urls import path, include 
from email_App.views import UserRegister, Varify_otp
from django.conf import settings
from django.conf.urls.static import static


urlpatterns = [
    path('admin/', admin.site.urls),
    path('candidate-register/', UserRegister.as_view(), name='register'),
    path('candidate-varify/', Varify_otp.as_view(), name='varify'),
    path('candidate-enrollment/', include('enrolment.urls')),
]
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)


