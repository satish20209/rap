from .models import *
from .serializers import *
from rest_framework.views import APIView
from rest_framework.response import Response
from django.core.mail import send_mail
import random
from django.conf import settings
from .models import CustomUser
from rest_framework import status

from django.core.cache import cache




def generateOTP(email) :
    """
    function to generate OTP
    """
    time = 180
    otp_key = email
    OTP = cache.get(otp_key)
    if not OTP:
        OTP = str(random.randint(100000,999999))
        cache.set(otp_key, OTP, time)
    return OTP,time



def verifyOTP(email,OTP):
    """
    function to verify OTP
    """



    otp_key = email
    return cache.get(otp_key) == OTP




# Create your views here.
class UserRegister(APIView):

    def post(self, request):
        serializer = CustomUserSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            email = serializer.data['email']
            subject = "Your Account Varification Mail."
            # otp = random.randint(1000, 9999)
            # request.session['otp'] = str(otp)
            otp, valid_for = generateOTP(email)
            message = f"WELCOME TO SHIVILA TECHNOLOGIES PRIVATE LIMITED.\n\n Your account varification code is {otp}"
            email_from = settings.EMAIL_HOST_USER
            send_mail(subject, message, email_from, [email]) 
            # user_obj = CustomUser.objects.get(email=email)
            # # user_obj.otp=otp
            # user_obj.save()

            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)








class Varify_otp(APIView):

    def post(self, request):
        data = request.data

        serializer = varifyAccountSerializer(data=data)

        if serializer.is_valid():
            email = serializer.data['email']
            otp = serializer.data['otp']

            user = CustomUser.objects.filter(email=email)
            
            if not user.exists():
                return Response({
                    
                    'message':'Something went wrong',
                    'data':'Invalid email'
                    })
                    
            user = user.first()
            # s_otp = request.session.get('otp')
            # newOTP = verifyOTP(user.email, otp)
            if verifyOTP(email,otp):
                user.is_verified = True
                user.save()
                return Response({"msg":"otp verified"},status=status.HTTP_200_OK)
            else:
                return Response({
                "msg" : "OTP not valid or OTP has expired."}, status=status.HTTP_400_BAD_REQUEST)
          
























            # print(newOTP)
            # print(s_otp)
            # if str(s_otp) != otp:
            #     return Response({
            #                     'message':'Something went wrong',
            #                     'data':'Invalid otp',
            #                     'email' : email,
            #                     'otp':otp
            #                     })      

            
            # user.is_varified = True
            # user.save()
            # return Response({
            #                 'message':'Email Verified',
            #                 'otp':otp,
            #                 'email' : email
            #                 })   