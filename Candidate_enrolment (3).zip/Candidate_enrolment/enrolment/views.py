from django.shortcuts import render

# Create your views here.
from .models import Enrollment
from rest_framework import viewsets
from rest_framework import permissions
from .serializers import EnrollmentSerializer


class EnrollmentViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows admission to be viewed or edited.
    """
    queryset = Enrollment.objects.all()
    serializer_class = EnrollmentSerializer
    permission_classes = [permissions.AllowAny]