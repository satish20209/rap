from rest_framework import serializers
from .models import Enrollment


class EnrollmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Enrollment
        fields = ['id','name_of_the_candidate','date_of_birth','father_name','mother_name','email','phone_number','wp_number','applied_domain','specilization','image']
         

