from django.contrib import admin

# Register your models here.
from django.contrib import admin
from .models import Enrollment


@admin.register(Enrollment)
class EnrollmentAdmin(admin.ModelAdmin):
    fields = ('name_of_the_candidate','date_of_birth','father_name','mother_name','email','phone_number','wp_number','applied_domain','specilization','image')


